package com.seven.sins.channel.service;

public class ChannelWriteServiceImpl implements ChannelWriteService {
}
