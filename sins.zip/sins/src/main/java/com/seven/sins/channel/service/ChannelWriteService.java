package com.seven.sins.channel.service;

public interface ChannelWriteService {
	
}
