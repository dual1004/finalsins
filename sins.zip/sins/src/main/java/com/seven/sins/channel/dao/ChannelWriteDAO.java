package com.seven.sins.channel.dao;

public class ChannelWriteDAO {
	
}
