package com.seven.sins.channel.service;

public class ChannelCommentServiceImpl implements ChannelCommentService{
}
