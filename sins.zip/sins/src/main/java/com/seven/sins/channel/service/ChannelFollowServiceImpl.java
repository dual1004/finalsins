package com.seven.sins.channel.service;

public class ChannelFollowServiceImpl implements ChannelFollowService {
}
